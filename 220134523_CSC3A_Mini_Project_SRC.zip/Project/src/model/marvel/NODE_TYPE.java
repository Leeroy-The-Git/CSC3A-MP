package model.marvel;

/**
 * Enum to define a {@link MarvelNode} as a HERO or a COMIC
 * @author JARED SWANZEN (220134523)
 */
public enum NODE_TYPE {
    HERO, COMIC
}
